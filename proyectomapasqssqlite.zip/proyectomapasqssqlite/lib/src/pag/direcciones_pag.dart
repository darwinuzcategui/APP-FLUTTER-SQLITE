import 'package:flutter/material.dart';


class DireccionesPag extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child:Text('Pag de Direcciones'),
      
    );
  }
}